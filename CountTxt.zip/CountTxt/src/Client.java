
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Client {
	public static void main (String[] args) throws Exception {

		//Server Communication-------------------------------------------------------------
		byte[] by=new byte[2002]; //Define byte 
		Socket socket= new Socket("localhost", 1234);//Create socket for server communication


		//Get server input
		InputStream in= socket.getInputStream(); //Get inputstream from server
		FileOutputStream fileOut= new FileOutputStream("new_file.txt");//Create an outputstream for new file
		in.read(by,0,by.length); //Read bytes from server input
		fileOut.write(by, 0, by.length); //Write on new file based on contents from server

		FileInputStream file = new FileInputStream("new_file.txt"); //Read new file
		Scanner myScanner = new Scanner(file); //Create a scanner for scanning file


		//Counting the words----------------------------------------------------------------

		//Create two arrayLists, one for the words and other for count
		ArrayList<String> words = new ArrayList<String>(); //This ArrayList will store all unique words
		ArrayList<Integer> count = new ArrayList<Integer>(); // This ArrayList stores number of occurences (same order as words)

		while(myScanner.hasNext()) {  //Scan file as long as it has a next-line 
			
			String nextWord= myScanner.next(); //Get next word (token)
			nextWord = nextWord.replaceAll(",",""); //remove ,-signs 
			String lowerWord = nextWord.toLowerCase(); // Turn words to lowercase
			
			//Look if word has been put in ArrayList
			if(words.contains(lowerWord)) {
				int index = words.indexOf(lowerWord);
				count.set(index, count.get(index)+1);  
			}
			//Else, add word to ArrayList
			else {
				words.add(lowerWord);
				count.add(1);
			}
		}

		//Get 10 most common words ----------------------------------------------------------
		//Create two empty ArrayLists for storing the words and number of occurences
		ArrayList <String> tenWords= new ArrayList <String> ();
		ArrayList <Integer> tenNumbers = new ArrayList <Integer> ();
		
		System.out.println(""); //Get a good-looking headline
		System.out.println("Most Common words in file: ");
		System.out.println("");
		int i=1;
		//Loop until ten words has been detected
		while(tenNumbers.size()<10) {
			//Integer i = 1; //To achieve a numbered list
			Integer maxVal = Collections.max(count); //Find max value of occurances
			Integer maxIdx = count.indexOf(maxVal); //Get index of that value
			tenWords.add(words.get(maxIdx)); //Add word with that index to ArrayList of common words
			tenNumbers.add(count.get(maxIdx)); //Add number of occurences with that index to ArrayList of numbers
			System.out.println( i+ " : '"+ words.get(maxIdx)+ "' occurs " + maxVal + " times"); //Print Results
			words.remove(words.get(maxIdx)); //Remove word from array for next loop
			count.remove(count.get(maxIdx)); //Remove number from array for next loop
			i++; //Add 1 to Integer
		}; 

		//Close-----------------------------------------------------------------------------
		socket.close();
		fileOut.close();
		myScanner.close();
	}

}
