import java.io.*;
import java.net.*;

public class Server {
	public static void main (String[] args) throws Exception {
		ServerSocket a = new ServerSocket(1234); //Create ServerSocket to connect to Client
		Socket b = a.accept(); //Accept connection with Client
		FileInputStream fileInp= new FileInputStream ("islands_in_the_stream.txt"); //Read file to send to Client
		
		byte by[]= new byte[2002]; //Create a Byte-object to store bytes from file
		fileInp.read(by,0,by.length); //Read file to bytes, from start to end of file
		OutputStream out= b.getOutputStream(); //Create OutputStream for server to send to Client
		out.write(by, 0, by.length); //Write bytes from file to OutputStream. 	
	}
}
